for filename in *.png; do
  optipng $filename
done
