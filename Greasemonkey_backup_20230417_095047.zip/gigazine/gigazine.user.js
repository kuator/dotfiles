// ==UserScript==
// @match https://gigazine.net/news/*
// @name     gigazine
// @version  1
// @grant    none
// ==/UserScript==

document.querySelector('#article').style.maxWidth = "674px";
document.querySelector('#article').style.margin = "auto";
document.querySelector('#article').style.padding = "0 20px";