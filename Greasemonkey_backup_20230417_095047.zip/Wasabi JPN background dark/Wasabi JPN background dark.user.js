// ==UserScript==
// @name     Wasabi JPN background dark
// @version  1
// @grant    none
// @match https://*.wasabi-jpn.com/*
// ==/UserScript==

let el = document.querySelector('#content');
el.style.backgroundColor = "#222";