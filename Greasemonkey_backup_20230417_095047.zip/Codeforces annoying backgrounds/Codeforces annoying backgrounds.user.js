// ==UserScript==
// @name     Codeforces annoying backgrounds
// @version  1
// @grant    none
// @match https://codeforces.com/*
// ==/UserScript==

document.body.style.backgroundImage = 'none';
document.body.style.backgroundColor = '#333';