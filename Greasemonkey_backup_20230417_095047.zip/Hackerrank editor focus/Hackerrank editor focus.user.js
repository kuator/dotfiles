// ==UserScript==
// @name     Hackerrank editor focus
// @version  1
// @grant    none
// @match https://www.hackerrank.com/challenges/*
// ==/UserScript==

// define a handler
document.addEventListener('keydown', (e) => {
    if (e.key.toLowerCase() === 'i' && e.ctrlKey) {
        e.preventDefault();
        // Add your code here
        var simulateMouseEvent = function(element, eventName, coordX, coordY) {
        element.dispatchEvent(new MouseEvent(eventName, {
          view: window,
          bubbles: true,
          cancelable: true,
          clientX: coordX,
          clientY: coordY,
          button: 0
        }));
      };

      var theButton = document.querySelector('.view-lines');


      var box = theButton.getBoundingClientRect(),
              coordX = box.left + (box.right - box.left) / 2,
              coordY = box.top + (box.bottom - box.top) / 2;

      simulateMouseEvent (theButton, "mousedown", coordX, coordY);
      simulateMouseEvent (theButton, "mouseup", coordX, coordY);
      simulateMouseEvent (theButton, "click", coordX, coordY);
          }
});
