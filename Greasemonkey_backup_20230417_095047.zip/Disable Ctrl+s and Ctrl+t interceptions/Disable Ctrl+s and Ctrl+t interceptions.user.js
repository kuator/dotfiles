// ==UserScript==
// @name           Disable Ctrl+s and Ctrl+t interceptions
// @description    Stop websites from highjacking keyboard shortcuts
//
// @run-at         document-start
// @match https://reader.ttsu.app/*
// ==/UserScript==

// Keycode for 's' and 't'. Add more to disable other ctrl+X interceptions
keycodes = [68, 76, 82];  

(window.opera ? document.body : document).addEventListener('keydown', function(e) {
//     alert(e.keyCode ); //uncomment to find more keyCodes
    if (keycodes.indexOf(e.keyCode) != -1 && e.ctrlKey) {
        e.cancelBubble = true;
        e.stopImmediatePropagation();
    // alert("Gotcha!"); //ucomment to check if it's seeing the combo
    } else {
     if ([91].indexOf(e.keyCode) != -1) {
        e.cancelBubble = true;
        e.stopImmediatePropagation();
    // alert("Gotcha!"); //ucomment to check if it's seeing the combo
    }
    }
    return false;
}, !window.opera);